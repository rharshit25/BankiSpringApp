package com.fis.bankapplication.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fis.bankapplication.dao.AccountDao;
import com.fis.bankapplication.model.Account;

@Service
@Transactional
public class AccountServiceImpl implements AccountService {
	@Autowired
	AccountDao dao;

	@Override
	public String addAccount(Account account) {
		return dao.addAccount(account);
	}

	@Override
	public Account getAccount(long getAcc) {
		return dao.getAccount(getAcc);
	}

	@Override

	public List<Account> getAllAccounts() {

		return dao.getAllAccounts();

	}
	
	@Override
	public String withdrawFromBalance(long getAcc, double withdrawAmount) {
		return dao.withdrawFromBalance(getAcc, withdrawAmount);

	}

	@Override
	public String depositIntoBalance(long getAcc, double depositAmount) {
		return dao.depositIntoBalance(getAcc, depositAmount);
	}

	@Override
	public String deleteAccount(long getAcc) {
		return dao.deleteAccount(getAcc);
	}

}

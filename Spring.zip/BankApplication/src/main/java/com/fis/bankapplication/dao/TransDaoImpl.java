package com.fis.bankapplication.dao;

 

import java.util.List;

 

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

 

import org.springframework.stereotype.Repository;

 

import com.fis.bankapplication.model.Account;
import com.fis.bankapplication.model.Transaction;

 

@Repository
public class TransDaoImpl implements TransDao{
	@PersistenceContext
	EntityManager entityManager;

 

	@Override
	public List<Transaction> getAllTransOfAcc(long getAcc) {
		TypedQuery<Transaction> query = entityManager.createQuery("select trans from Transaction trans where trans.accNoTo = ?1 or trans.accNoFrom = ?1", Transaction.class);
		query.setParameter(1, getAcc);
		return query.getResultList();
	}

 

	@Override
	public String fundTransferNEFT (Transaction transaction) {
		Account acc1 = new Account();
		Account acc2 = new Account();
		acc1 = entityManager.find(Account.class, transaction.getAccNoFrom());
		acc2 = entityManager.find(Account.class, transaction.getAccNoTo());
		acc1.setBalance(acc1.getBalance() - transaction.getAmount());
		acc2.setBalance(acc2.getBalance() + transaction.getAmount());
		entityManager.persist(transaction);
		return "NEFT Transaction performed Successfully...";
	}

 

	@Override
	public String fundTransferRTGS(Transaction transaction) {
		Account acc1 = new Account();
		Account acc2 = new Account();
		acc1 = entityManager.find(Account.class, transaction.getAccNoFrom());
		acc2 = entityManager.find(Account.class, transaction.getAccNoTo());
		acc1.setBalance(acc1.getBalance() - transaction.getAmount());
		acc2.setBalance(acc2.getBalance() + transaction.getAmount());
		entityManager.persist(transaction);
		entityManager.persist(transaction);
		return "RTGS Transaction performed Successfully...";
	}

 

	@Override
	public String fundTransferIMPS(Transaction transaction) {
		Account acc1 = new Account();
		Account acc2 = new Account();
		acc1 = entityManager.find(Account.class, transaction.getAccNoFrom());
		acc2 = entityManager.find(Account.class, transaction.getAccNoTo());
		acc1.setBalance(acc1.getBalance() - transaction.getAmount());
		acc2.setBalance(acc2.getBalance() + transaction.getAmount());
		entityManager.persist(transaction);
		return "IMPS Transaction performed Successfully...";
	}

}
package com.fis.bankapplication.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.fis.bankapplication.model.Account;

@Repository
public class AccountDaoImpl implements AccountDao{
	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	public String addAccount(Account account) {
		entityManager.persist(account);
		return "Account Added Successfully...";
	}

	@Override
	public Account getAccount(long getAcc) {
		return entityManager.find(Account.class, getAcc);
	}

	@Override
	public List<Account> getAllAccounts() {

		TypedQuery<Account> query = entityManager.createQuery("select acc from Account acc", Account.class);

		return query.getResultList();

	}
	
	@Override
	public String withdrawFromBalance(long getAcc, double withdrawAmount) {
		Account account = this.getAccount(getAcc);
		account.setBalance(account.getBalance() - withdrawAmount);
		return "Amount Withdrawn Successfully...";
	}

	@Override
	public String depositIntoBalance(long getAcc, double depositAmount) {
		Account account = this.getAccount(getAcc);
		account.setBalance(account.getBalance() + depositAmount);
		return "Amount Deposited Successfully...";
	}

	@Override
	public String deleteAccount(long getAcc) {
		entityManager.remove(getAccount(getAcc));
		return "Account Removed Successfully";
	}

}

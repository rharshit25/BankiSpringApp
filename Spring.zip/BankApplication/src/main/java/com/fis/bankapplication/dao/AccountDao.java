package com.fis.bankapplication.dao;

import java.util.List;

import com.fis.bankapplication.model.Account;

public interface AccountDao {
	public abstract String addAccount(Account account);
	
	public abstract Account getAccount(long getAcc);
	
	public abstract List<Account> getAllAccounts();
	
	public abstract String withdrawFromBalance(long getAcc, double withdrawAmount);
	
	public abstract String depositIntoBalance(long getAcc, double depositAmount);
	
	public abstract String deleteAccount(long getAcc);
}

package com.fis.bankapplication.controller;

import java.util.List;

 

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

 

import com.fis.bankapplication.model.Account;
import com.fis.bankapplication.model.Transaction;
import com.fis.bankapplication.service.AccountService;
import com.fis.bankapplication.service.TransService;

@RestController
@RequestMapping("/accounts")
public class AccountController {

	@Autowired
	AccountService service;
	@Autowired
	TransService transService;

 

	@PostMapping("/addAccount") // http://localhost:8080/accounts/addAccount
	public String addAccount(@RequestBody Account account) {
		return service.addAccount(account);
	}

 

	@GetMapping("/getAccount") // http://localhost:8080/accounts/getAccount
	public Account getAccount(@RequestBody long getAcc) {
		return service.getAccount(getAcc);
	}

	@GetMapping("/getAllAccounts") // http://localhost:8080/accounts/getAllAccounts
	public List<Account> getAllAccounts() {
		return service.getAllAccounts();
	}

	@GetMapping("/getAllTransOfAcc") // http://localhost:8080/accounts/getAllTransOfAcc
	public List<Transaction> getAllTransOfAcc(@RequestBody long getAcc){
		return transService.getAllTransOfAcc(getAcc);
	}

	@PutMapping("/transactions/fundTransfer/{transType}/") // http://localhost:8080/accounts/transactions/fundTransfer/transType
	public String fundTransferType (@PathVariable("transType") String transType, @RequestBody Transaction transaction) {
		if (transType.equalsIgnoreCase("neft")) {
			return transService.fundTransferNEFT(transaction);
		}
		else if (transType.equalsIgnoreCase("rtgs")) {
			return transService.fundTransferRTGS(transaction);
		}
		else if (transType.equalsIgnoreCase("imps")) {
			return transService.fundTransferIMPS(transaction);
		}
		else {
			return "Wrong Transaction Type...";
		}
	}

 

	@PutMapping("/withdrawFromBalance/{accno}/{amount}") // http://localhost:8080/accounts/withdrawFromBalance/101/400
	public String withdrawFromBalance(@PathVariable("accno") long getAcc , @PathVariable("amount") double withdrawAmount) {
		return service.withdrawFromBalance(getAcc, withdrawAmount);
	}

	@PutMapping("/depositIntoBalance/{accno}/{amount}") // http://localhost:8080/accounts/depositIntoBalance
	public String depositIntoBalance(@PathVariable("accno") long getAcc , @PathVariable("amount") double depositAmount) {
		return service.depositIntoBalance(getAcc, depositAmount);
	}

	@DeleteMapping("/deleteAccount") // http://localhost:8080/accounts/deleteAccount
	public String deleteAccount(@RequestBody long getAcc) {
		return service.deleteAccount(getAcc);
	}

}
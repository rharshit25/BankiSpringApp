package com.fis.bankapplication.service;

 

import java.util.List;

 

import javax.transaction.Transactional;

 

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

 

import com.fis.bankapplication.dao.TransDao;
import com.fis.bankapplication.model.Transaction;

 

@Service
@Transactional
public class TransServiceImpl implements TransService{
	@Autowired
	TransDao dao;

 

	@Override
	public List<Transaction> getAllTransOfAcc(long getAcc) {
		return dao.getAllTransOfAcc(getAcc);
	}

 

	@Override
	public String fundTransferNEFT(Transaction transaction) {
		return dao.fundTransferNEFT(transaction);
	}

 

	@Override
	public String fundTransferRTGS(Transaction transaction) {
		return dao.fundTransferRTGS(transaction);
	}

 

	@Override
	public String fundTransferIMPS(Transaction transaction) {
		return dao.fundTransferIMPS(transaction);
	}

 

}